/* --- geometry and timing of the menu --- */

var MENU_POS3 = new Array();

	// item sizes for different levels of menu

	MENU_POS3['height'] = [26, 20];

	MENU_POS3['width'] = [150, 100];

	// menu block offset from the origin:

	//	for root level origin is upper left corner of the page

	//	for other levels origin is upper left corner of parent item

	MENU_POS3['block_top'] = [120, 20];

	MENU_POS3['block_left'] = [15, 50];

	// offsets between items of the same level

	MENU_POS3['top'] = [33, 22];

	MENU_POS3['left'] = [0, 0];

	// time in milliseconds before menu is hidden after cursor has gone out

	// of any items

	MENU_POS3['hide_delay'] = [100, 100];

	

/* --- dynamic menu styles ---

note: you can add as many style properties as you wish but be not all browsers

are able to render them correctly. The only relatively safe properties are

'color' and 'background'.

*/

var MENU_STYLES3 = new Array();

	// default item state when it is visible but doesn't have mouse over

	MENU_STYLES3['onmouseout'] = [

		'color', ['#ffffff', '#000000'], 

		'background', ['#000066', '#81D6FE'],

		'fontWeight', ['normal', 'normal'],

		'textDecoration', ['none', 'none'],

	];

	// state when item has mouse over it

	MENU_STYLES3['onmouseover'] = [

		'color', ['#ffffff', '#000000'], 

		'background', ['#6699cc', '#C0C0C0'],

		'fontWeight', ['normal', 'bold'],

		'textDecoration', ['underline', 'none'],

	];

	// state when mouse button has been pressed on the item

	MENU_STYLES3['onmousedown'] = [

		'color', ['#ffffff', '#000000'], 

		'background', ['#99cccc', '#CCCCCC'],

		'fontWeight', ['normal', 'bold'],

		'textDecoration', ['underline', 'none'],

	];

	