#!/usr/local/bin/perl -w
require 5.001;
use strict;
use DB_File;


=head1 NAME

webcrawl - create a full-text index to a Web site

=head1 SYNOPSIS

  webcrawl directory

=head1 DESCRIPTION

See my article in Webmonkey for a complete description:
http://www.webmonkey.com/code/97/16/index2a.html

=head1 AUTHOR

Brian Slesinsky

=cut


if($#ARGV!=0) {
    die "Usage: $0 directory";
}
chdir $ARGV[0] or die "chdir: $!";


# create a new index

unlink("search_index.db.new");
my %db;
dbmopen(%db, "search_index.db.new", 0644) or die "dbmopen: $!";


# find all HTML files

open(FILES, "/bin/find . -name '*.html' -print |") or die "open for find: $!";

my $fileno = 0;
my $filename;
while(defined($filename = <FILES>)) {
    print "indexing $filename";
    chop $filename;


    # read file's contents into $html

    open(HTML, $filename) or do { warn "open $filename: $!"; next; };
    my $html = join('', <HTML>);
    close HTML;


    # store a link to the file

    my ($title) = ($html =~ /<title>([^<]*)/i);
    $title = $filename if(!defined $title);
    $db{--$fileno} = "<a href=\"$filename\">$title</a>";


    # extract the words from the HTML

    $html =~ s/<[^>]+>//g;
    $html =~ tr/A-Z/a-z/;
    my @words = ($html =~ /\w+/g);


    # add this page to the inverted index

    my $last = "";
    for (sort @words) {
	next if($_ eq $last);
	$last = $_;
	$db{$_} = defined $db{$_} ? $db{$_}.$fileno : $fileno;
    }
}


# close the new index and replace any existing index

untie %db;
unlink("search_index.db");
link("search_index.db.new","search_index.db") or die "link: $!";
unlink("search_index.db.new") or die "unlink: $!";

__END__


# and here is a three-line script that does about the same thing:

#!/usr/local/bin/perl -- web find part 1: cd your_web_dir and run  -bslesins 
use DB_File;dbmopen%d,db,420;open F,"find -print|";for(<F>){chop;if(/tml$/){
$n=$_;open H,$_;$_=join'',<H>;/title>([^<]+)/i;$d{--$f}="$n\">$1 $n";tr[A-Z]
[a-z];s/<[^>]+>//g;for(sort /\w+/g){$d{$_}="$d{$_}$f"if($l ne$_);$l=$_;}}}

